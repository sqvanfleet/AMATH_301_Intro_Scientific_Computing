#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  9 07:48:33 2024

@author: samvanfleet
"""

print("Hello World")