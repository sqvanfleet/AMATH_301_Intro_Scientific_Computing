#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 10:49:23 2024

@author: samvanfleet
"""

import numpy as np


x = 10
y = np.array([1,2,3,4,5])

z = x*y

test_suite = [
    {
        "test_name": "Problem 1",
        "variable_name": "x",
        "description": "Initialize x",
        "atol": 1e-8,
        "score": 1,
        "hint_not_defined": "Double check that you named your answer x.",
        # "hint_tolerance": "",
        "hint_wrong_type_python": "Make sure you are using an int."
    },
    {
        "test_name": "Problem 2",
        "variable_name": "y",
        "description": "Initialize the matrix",
        "atol": 1e-8,
        "score": 1,
        "hint_not_defined": "Double check that you named your answer A1.",
        # "hint_tolerance": "",
        "hint_wrong_type_python": "Make sure you are using a numpy array.",
        "hint_wrong_size_python": "Your answer should be a 2x2 2-dimensional array.",
    },
    {
        "test_name": "Problem 3",
        "variable_name": "z",
        "description": "scalar mult",
        "atol": 1e-8,
        "score": 1,
        "hint_not_defined": "Double check that you named your answer A1.",
        # "hint_tolerance": "",
        "hint_wrong_type_python": "Make sure you are using a numpy array.",
        "hint_wrong_size_python": "Your answer should be a 2x2 2-dimensional array.",
    },
]

supported_platforms = ["python"]#, "matlab"]
#matlab_credentials = "~/gspack_uw_amath_matlab_credentials"
requirements = ["numpy"]











