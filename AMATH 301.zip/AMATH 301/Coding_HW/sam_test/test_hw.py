#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 11:00:07 2024

@author: samvanfleet
"""

import numpy as np


x = 10
y = np.array([1,2,3,4,5])

z = x*y