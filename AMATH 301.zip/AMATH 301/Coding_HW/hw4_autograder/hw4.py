#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 13:14:53 2024

@author: samvanfleet
"""

import numpy as np


#function for Naive Gaussian Elimination based on the pseudocode on page 
#77.



def Naive_Gauss(A,b):
    #A is a 2D array of shape (n,n)
    #b is a 1D array of shape (n,)
    A = A.astype("float")
    b = b.astype("float")
    n = A.shape[0] # Gets the number of rows of A
    
    #Forward Elimination
    

    xmult = 0 #Initialize xmult
    #Forward Elimination 
    for k in range(0,n-1):
        for i in range(k+1,n):
            xmult = A[i,k]/A[k,k] #multiplier of the replacement operation
            for j in range(k,n):
                A[i,j] = A[i,j] - xmult*A[k,j]
            b[i] = b[i] - xmult*b[k]
    
    #backwards substitution 
    x = np.zeros(n) #initialize a 1D array of zeros for x
    
    x[n-1] = b[n-1]/A[n-1,n-1] # This corresponds to the last row in our system
    
    sum = 0 #initialize the sum variable
    for i in range(n-2,-1,-1):
        sum = b[i] #first term in the formula for x_i
        
        for j in range(i+1,n):
            sum = sum - A[i,j]*x[j]
            
        x[i] = sum/A[i,i]
    
    
    return x
        

#First test

A1 = np.array([[1,2,3],[2,6,10],[3,14,28]])
b1 = np.array([1,0,-8])



x1 = Naive_Gauss(A1,b1)


#Second test



A2 = np.array([[4,-1,-1,0],[-1,4,0,-1],[-1,0,4,-1],[0,-1,-1,4]])
b2 = np.array([30,60,40,70])

x2 = Naive_Gauss(A2,b2)


#Third test

A3 = np.zeros((15,15))



for i in range(15):
    for j in range(15):
        A3[i,j] = -1 + 2*np.min([i+1,j+1])




b3 = A3@np.ones(15)

x3 = Naive_Gauss(A3,b3)

print("x1 = ", x1)

print("x2 = ",x2)


print("x3 = ", x3)